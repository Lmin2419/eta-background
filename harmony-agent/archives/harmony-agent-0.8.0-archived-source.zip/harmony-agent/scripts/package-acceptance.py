#!/usr/bin/env python3
"""Bundle reviewed install projects, source, acceptance records, and real build logs."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
version = json.loads((root / 'package.json').read_text())['version']
prefix = f'harmony-agent-{version}'
report = json.loads((dist / 'PACKAGING_VALIDATION_0.8.json').read_text())
assert report['result'] == 'passed'
for item in report['artifacts']:
    assert hashlib.sha256((dist / item['file']).read_bytes()).hexdigest() == item['sha256'], 'Re-run release validation after export'
entries = {'00_先读_安装与核验.md': (root / 'docs/DELIVERY_0.8.md').read_bytes()}
for suffix, folder in [('upgrade', '安装工程'), ('deveco', '安装工程'), ('source', '源码')]:
    path = dist / f'{prefix}-{suffix}.zip'
    entries[folder + '/' + path.name] = path.read_bytes()
for path in sorted((root / 'docs').rglob('*')):
    if path.is_file():
        entries['验收资料/' + path.relative_to(root / 'docs').as_posix()] = path.read_bytes()
for filename in ['typecheck-0.8.log', 'test-0.8.log', 'native-0.8.log', 'build-0.8.log', 'export-build-0.8.log', 'export-dependencies-0.8.log', 'PACKAGING_VALIDATION_0.8.json']:
    entries['验证记录/' + filename] = (dist / filename).read_bytes()
entries['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items())).encode()
destination = dist / f'{prefix}-acceptance.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as package:
    for name, data in sorted(entries.items()):
        package.writestr(name, data)
with zipfile.ZipFile(destination) as package:
    assert package.testzip() is None
    for name, data in entries.items():
        assert package.read(name) == data
checksum = hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_suffix('.zip.sha256').write_text(checksum + '  ' + destination.name + '\n')
print(destination)
print('SHA-256:', checksum)
