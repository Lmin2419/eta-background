#!/usr/bin/env python3
"""Export source and a DevEco project with prebuilt ARM64 libraries; never include credentials."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
dist.mkdir(exist_ok=True)
hap = dist / 'harmony-agent-0.8.0-unsigned.hap'
if not hap.is_file():
    raise SystemExit('Run scripts/build.sh first.')
profile = json.loads((root / 'build-profile.json5').read_text())
if profile.get('app', {}).get('signingConfigs'):
    raise SystemExit('Export requires an unsigned build profile; remove local signing credentials first.')
roots = ['AppScope', 'entry', 'hvigor', 'scripts', 'tests', 'docs']
files = [root / p for p in ['README.md', 'THIRD_PARTY_NOTICES.md', '.gitignore', 'build-profile.json5',
                          'hvigorfile.ts', 'oh-package.json5', 'package.json', 'package-lock.json', 'tsconfig.json']]
ignored = {'build', 'oh_modules', 'node_modules', '.cxx', '.hvigor', '__pycache__', 'libs'}
for folder in roots:
    for p in (root / folder).rglob('*'):
        if p.is_file() and not (set(p.relative_to(root).parts) & ignored):
            if p.suffix in ('.p12', '.p7b', '.pem', '.cer', '.log', '.pyc'):
                raise SystemExit(f'Refusing to export credential or generated file: {p}')
            files.append(p)
with zipfile.ZipFile(hap) as z:
    libraries = {name: z.read(name) for name in z.namelist() if name.startswith('libs/arm64-v8a/') and name.endswith('.so')}
    assert 'libs/arm64-v8a/libagent_hdc.so' in libraries
for prebuilt, suffix in [(False, 'source'), (True, 'deveco')]:
    destination = dist / f'harmony-agent-0.8.0-{suffix}.zip'
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as out:
        for p in sorted(files):
            relative = p.relative_to(root).as_posix()
            if prebuilt and relative == 'build-profile.json5':
                # DevEco creates a signing configuration named "default". The product must
                # reference it as well; generated credentials alone do not sign the HAP.
                install_profile = json.loads(p.read_text())
                for product in install_profile['app']['products']:
                    product['signingConfig'] = 'default'
                out.writestr('harmony-agent/' + relative, json.dumps(install_profile, indent=2) + '\n')
            elif prebuilt and relative == 'entry/build-profile.json5':
                out.writestr('harmony-agent/' + relative, json.dumps({'apiType':'stageMode','buildOption':{},'targets':[{'name':'default'}]}))
            else:
                out.write(p, 'harmony-agent/' + relative)
        if prebuilt:
            for name, data in libraries.items():
                out.writestr('harmony-agent/entry/' + name, data)
            out.writestr('harmony-agent/PREBUILT_PROJECT.md',
                '# 预编译 DevEco 工程\n\n本包使用 entry/libs/arm64-v8a 中的原生库，供 Windows/macOS/Linux 上签名安装。'
                '直接用 DevEco 打开、同步依赖、配置自己的调试签名并运行。编译 SDK 为 API 26，目标及最低 API 20；模型网络功能要求运行系统 API ≥ 23。\n\n'
                '产品已关联名称为 default 的签名配置，但包中不包含证书。请先在 DevEco 自动生成自己的 default 签名，再运行。'
                '若自定义了签名配置名，应同步修改根目录 build-profile.json5 的 app.products[].signingConfig。'
                '出现 no signature file 时，按 README 的签名排查步骤检查该关联。\n\n'
                'C++ 源码保留供审阅，但本包不在 DevEco 中编译 C++。修改 C++ 后，使用 source.zip 中的完整工程重新构建和导出。'
                '不要用旧预编译库验证新的原生改动。详情见 README.md。\n')
    print(destination)
# Overlay only application code/resources. Keep the user's signing and native build configuration.
upgrade = dist / 'harmony-agent-0.8.0-upgrade.zip'
with zipfile.ZipFile(upgrade, 'w', compression=zipfile.ZIP_DEFLATED) as out:
    for p in sorted(files):
        relative = p.relative_to(root).as_posix()
        if relative == 'AppScope/app.json5' or relative == 'entry/src/main/module.json5' or relative.startswith(('entry/src/main/ets/', 'entry/src/main/resources/')):
            out.write(p, relative)
    out.writestr('升级说明.txt', (root / 'docs/UPGRADE_0.8.md').read_text())
    out.writestr('虚拟屏实验说明.txt', (root / 'docs/VIRTUAL_SCREEN_ACL.md').read_text())
print(upgrade)
acl = dist / 'harmony-agent-0.8.0-virtual-screen-acl.zip'
with zipfile.ZipFile(acl, 'w', compression=zipfile.ZIP_DEFLATED) as out:
    manifest = json.loads((root / 'entry/src/main/module.json5').read_text())
    assert not any(p['name'] == 'ohos.permission.ACCESS_VIRTUAL_SCREEN' for p in manifest['module']['requestPermissions'])
    manifest['module']['requestPermissions'].append({'name':'ohos.permission.ACCESS_VIRTUAL_SCREEN'})
    out.writestr('entry/src/main/module.json5', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    out.writestr('虚拟屏实验说明.txt', (root / 'docs/VIRTUAL_SCREEN_ACL.md').read_text())
print(acl)
with (dist / 'SHA256SUMS').open('w') as checksums:
    for path in sorted(dist.glob('harmony-agent-0.8.0-*')):
        if path.suffix not in ('.hap', '.zip') or path.name.endswith('-acceptance.zip'):
            continue
        checksums.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n')
