#!/usr/bin/env python3
"""Verify exported 0.8 artifacts against the workspace; does not test device behavior."""
import csv
import hashlib
import json
from pathlib import Path
import struct
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
version = json.loads((root / 'package.json').read_text())['version']
prefix = f'harmony-agent-{version}'
checks = []


def check(condition, name):
    if not condition:
        raise SystemExit('FAIL: ' + name)
    checks.append(name)


with (root / 'docs/IMPLEMENTATION_STATUS_0.8.csv').open(encoding='utf-8-sig', newline='') as stream:
    rows = list(csv.DictReader(stream))
check(len(rows) == 83 and len({r['id'] for r in rows}) == 83, '83 unique backlog IDs')
check((root / 'docs/IMPLEMENTATION_STATUS_0.8.csv').read_bytes() == (root / 'docs/ETA_PARITY_BACKLOG.csv').read_bytes(), 'backlog snapshots agree')
for row in rows:
    for path in row['实现定位'].split(';'):
        check((root / path).is_file(), 'source reference: ' + row['id'] + ' ' + path)

with zipfile.ZipFile(dist / f'{prefix}-unsigned.hap') as hap:
    check(hap.testzip() is None, 'HAP ZIP integrity')
    module = json.loads(hap.read('module.json'))
    check(module['app']['versionName'] == version and module['app']['versionCode'] == 80000, 'HAP release version')
    check(module['app']['bundleName'] == 'com.example.harmonyagent', 'HAP expected bundle')
    check(len(hap.read('ets/modules.abc')) > 100, 'ArkTS bytecode exists')
    libraries = {n: hap.read(n) for n in hap.namelist() if n.startswith('libs/arm64-v8a/') and n.endswith('.so')}
    check('libs/arm64-v8a/libagent_hdc.so' in libraries and 'libs/arm64-v8a/libc++_shared.so' in libraries, 'native dependencies included')
    for name, binary in libraries.items():
        check(binary[:4] == b'\x7fELF' and struct.unpack('<H', binary[18:20])[0] == 183, 'ARM64: ' + name)

for suffix in ['source', 'deveco', 'upgrade', 'virtual-screen-acl']:
    path = dist / f'{prefix}-{suffix}.zip'
    with zipfile.ZipFile(path) as package:
        names = package.namelist()
        check(package.testzip() is None, suffix + ' ZIP integrity')
        check(len(names) == len(set(names)), suffix + ' unique entries')
        for name in names:
            check(not name.startswith('/') and '..' not in Path(name).parts, suffix + ' safe path: ' + name)
            check(Path(name).suffix.lower() not in {'.p12', '.p7b', '.pem', '.cer', '.key'}, suffix + ' no certificate file: ' + name)
        if suffix in ['source', 'deveco']:
            profile = json.loads(package.read('harmony-agent/build-profile.json5'))
            check(not profile['app']['signingConfigs'], suffix + ' no personal signing credentials')
            if suffix == 'deveco':
                check(all(p.get('signingConfig') == 'default' for p in profile['app']['products']), 'DevEco product links generated default signature')
                module = json.loads(package.read('harmony-agent/entry/build-profile.json5'))
                check('externalNativeOptions' not in module.get('buildOption', {}), 'DevEco uses prebuilt native libraries')
                for name, binary in libraries.items():
                    check(package.read('harmony-agent/entry/' + name) == binary, 'DevEco native parity: ' + name)
            for name in names:
                relative = name.removeprefix('harmony-agent/')
                source = root / relative
                if source.is_file() and relative not in ['build-profile.json5', 'entry/build-profile.json5']:
                    check(package.read(name) == source.read_bytes(), suffix + ' source parity: ' + relative)
        if suffix == 'upgrade':
            check('build-profile.json5' not in names and 'entry/build-profile.json5' not in names, 'upgrade preserves signing/build configuration')
            for source in (root / 'entry/src/main/ets').rglob('*'):
                if source.is_file():
                    relative = source.relative_to(root).as_posix()
                    check(package.read(relative) == source.read_bytes(), 'upgrade source parity: ' + relative)
            manifest = json.loads(package.read('entry/src/main/module.json5'))
            check(not any(p['name'] == 'ohos.permission.ACCESS_VIRTUAL_SCREEN' for p in manifest['module']['requestPermissions']), 'normal upgrade does not require virtual-screen ACL')

report = {'version': version, 'result': 'passed', 'checks': len(checks), 'scope': 'Packaging and source parity only; real-device gates remain pending.', 'artifacts': []}
for path in sorted(dist.glob(prefix + '-*')):
    if path.suffix in ['.hap', '.zip'] and not path.name.endswith('-acceptance.zip'):
        report['artifacts'].append({'file': path.name, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(dist / 'PACKAGING_VALIDATION_0.8.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
